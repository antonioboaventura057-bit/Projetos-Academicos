//Página index
function index(){    
    window.location.href="index.php";
}

//Página login
function login(){    
    window.location.href="login.php";
}

//Página loginFalha
function loginFalha(){    
    window.location.href="loginFalha.php";
}

//Página loginSucesso
function loginSucesso(){    
    window.location.href="loginSucesso.php";
}

//Página livroListagem
function livroListagem(){    
    window.location.href="livroListagem.php";
}

//Página livroExcluir
function livroExcluir(){    
    window.location.href="livroExcluir.php";
}

//Página livroCadastro
function livroCadastro(){    
    window.location.href="livroCadastro.php";
}

//Página livroAlterar
function livroAlterar(){    
    window.location.href="livroAlterar.php";
}

//Página leitorListagem
function leitorListagem(){    
    window.location.href="leitorListagem.php";
}

//Página leitorExcluir
function leitorExcluir(){    
    window.location.href="leitorExcluir.php";
}

//Página leitorCadastro
function leitorCadastro(){    
    window.location.href="leitorCadastro.php";
}

//Página leitorAlterar
function leitorAlterar(){    
    window.location.href="leitorAlterar.php";
}

//Página emprestimoDevolucaoListagem
function emprestimoDevolucaoListagem(){    
    window.location.href="emprestimoDevolucaoListagem.php";
}

//Página emprestimoCadastro
function emprestimoCadastro(){    
    window.location.href="emprestimoCadastro.php";
}

//Página devolucaoCadastro
function devolucaoCadastro(){    
    window.location.href="devolucaoCadastro.php";
}